package com.oscaralmagro.autoqueue

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun clean(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .lowercase()
        .replace(Regex("[^a-z0-9 ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

object BotState {
    @Volatile var running = false
    @Volatile var serviceOn = false
    @Volatile var pkg = ""
    private val logs = ArrayList<String>()

    @Synchronized
    fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        logs.add("[$t] $msg")
        while (logs.size > 80) logs.removeAt(0)
    }

    @Synchronized
    fun logText(): String = logs.joinToString("\n")
}

object Cfg {
    private val DEF = mapOf(
        "kwReady" to "listo,ready",
        "kwAgain" to "jugar de nuevo,play again",
        "kwLobby" to "volver a la sala,return to lobby,volver al lobby"
    )

    fun prefs(c: Context): SharedPreferences =
        c.getSharedPreferences("aq", Context.MODE_PRIVATE)

    fun list(p: SharedPreferences, key: String): List<String> =
        (p.getString(key, DEF[key]) ?: "").split(",").map { clean(it) }.filter { it.isNotEmpty() }

    fun toJson(c: Context): JSONObject {
        val p = prefs(c)
        val o = JSONObject()
        for ((k, v) in DEF) o.put(k, p.getString(k, v))
        o.put("dReady", p.getInt("dReady", 30))
        o.put("dAgain", p.getInt("dAgain", 30))
        o.put("dLobby", p.getInt("dLobby", 10))
        o.put("interval", p.getInt("interval", 3))
        return o
    }

    fun save(c: Context, json: String) {
        val o = JSONObject(json)
        val e = prefs(c).edit()
        for ((k, v) in DEF) e.putString(k, o.optString(k, v))
        e.putInt("dReady", o.optInt("dReady", 30).coerceIn(1, 600))
        e.putInt("dAgain", o.optInt("dAgain", 30).coerceIn(1, 600))
        e.putInt("dLobby", o.optInt("dLobby", 10).coerceIn(1, 600))
        e.putInt("interval", o.optInt("interval", 3).coerceIn(2, 30))
        e.apply()
    }
}

class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.setBackgroundColor(0xFF15112B.toInt())
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface
        fun state(): String {
            val o = JSONObject()
            o.put("running", BotState.running)
            o.put("serviceOn", BotState.serviceOn)
            o.put("pkg", BotState.pkg)
            o.put("log", BotState.logText())
            return o.toString()
        }

        @JavascriptInterface
        fun config(): String = Cfg.toJson(applicationContext).toString()

        @JavascriptInterface
        fun save(json: String) {
            try {
                Cfg.save(applicationContext, json)
                BotState.log("Ajustes guardados.")
            } catch (e: Exception) {
                BotState.log("No se pudieron guardar los ajustes.")
            }
        }

        @JavascriptInterface
        fun start() {
            BotState.running = true
            BotState.log("Auto queue iniciado. Abre Fortnite.")
        }

        @JavascriptInterface
        fun stop() {
            BotState.running = false
            BotState.log("Auto queue detenido.")
        }

        @JavascriptInterface
        fun openAccessibility() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        @JavascriptInterface
        fun openAppInfo() {
            runOnUiThread {
                startActivity(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + packageName)
                    )
                )
            }
        }

        @JavascriptInterface
        fun openUrl(u: String) {
            if (u.startsWith("https://")) {
                runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
            }
        }
    }
}
