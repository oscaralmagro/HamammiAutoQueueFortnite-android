package com.oscaralmagro.autoqueue

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.Executors

class Hit(val score: Float, val cx: Int, val cy: Int)

class Prep(
    val w: Int,
    val h: Int,
    val dx: IntArray,
    val dy: IntArray,
    val tz: FloatArray,
    val sumTz2: Double
)

object Matcher {
    private val raw = HashMap<String, Bitmap>()
    private val prepared = HashMap<String, Prep>()

    fun gray(c: Int): Int =
        (((c shr 16) and 0xFF) * 30 + ((c shr 8) and 0xFF) * 59 + (c and 0xFF) * 11) / 100

    private fun template(ctx: Context, key: String): Bitmap {
        val cached = raw[key]
        if (cached != null) return cached
        val bmp = ctx.assets.open("tpl/" + key + ".png").use { BitmapFactory.decodeStream(it) }
        raw[key] = bmp
        return bmp
    }

    fun prep(ctx: Context, key: String, scale: Float): Prep {
        val id = key + "@" + Math.round(scale * 100)
        val c = prepared[id]
        if (c != null) return c
        val t = template(ctx, key)
        val w = Math.max(8, Math.round(t.width * scale / 4f))
        val h = Math.max(6, Math.round(t.height * scale / 4f))
        val sc = Bitmap.createScaledBitmap(t, w, h, true)
        val px = IntArray(w * h)
        sc.getPixels(px, 0, w, 0, 0, w, h)
        val n = ((w + 1) / 2) * ((h + 1) / 2)
        val dx = IntArray(n)
        val dy = IntArray(n)
        val v = FloatArray(n)
        var k = 0
        var sum = 0.0
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                dx[k] = x
                dy[k] = y
                v[k] = gray(px[y * w + x]).toFloat()
                sum += v[k]
                k++
                x += 2
            }
            y += 2
        }
        val mean = (sum / n).toFloat()
        var s2 = 0.0
        for (i in 0 until n) {
            v[i] = v[i] - mean
            s2 += (v[i] * v[i]).toDouble()
        }
        val p = Prep(w, h, dx, dy, v, s2)
        prepared[id] = p
        return p
    }

    fun find(g: IntArray, W: Int, H: Int, p: Prep): Hit {
        var best = -1f
        var bx = 0
        var by = 0
        val n = p.tz.size
        val nd = n.toDouble()
        var y = 0
        while (y <= H - p.h) {
            var x = 0
            while (x <= W - p.w) {
                var sw = 0L
                var sw2 = 0L
                var cross = 0.0
                for (i in 0 until n) {
                    val v = g[(y + p.dy[i]) * W + x + p.dx[i]]
                    sw += v
                    sw2 += v * v
                    cross += v * p.tz[i]
                }
                val varW = sw2.toDouble() - sw.toDouble() * sw.toDouble() / nd
                if (varW > 100.0) {
                    val ncc = (cross / Math.sqrt(p.sumTz2 * varW)).toFloat()
                    if (ncc > best) {
                        best = ncc
                        bx = x
                        by = y
                    }
                }
                x += 2
            }
            y += 2
        }
        return Hit(best, (bx + p.w / 2) * 4, (by + p.h / 2) * 4)
    }
}

class QueueService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    @Volatile
    private var busy = false

    @Volatile
    private var pausedUntil = 0L
    private var lastWait = ""
    private var lastErr = -1

    private val tick = object : Runnable {
        override fun run() {
            try {
                scan()
            } catch (e: Exception) {
                busy = false
                BotState.log("Error: " + e.message)
            }
            val sec = Cfg.prefs(this@QueueService).getInt("interval", 3)
            handler.postDelayed(this, sec * 1000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        BotState.serviceOn = true
        BotState.log("Servicio de accesibilidad activo.")
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        BotState.serviceOn = false
        BotState.running = false
        handler.removeCallbacks(tick)
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            BotState.pkg = e.packageName?.toString() ?: ""
        }
    }

    private fun scan() {
        if (!BotState.running || busy) return
        if (System.currentTimeMillis() < pausedUntil) return
        val now = try {
            rootInActiveWindow?.packageName?.toString()
        } catch (e: Exception) {
            null
        }
        val pkg = if (!now.isNullOrEmpty()) now else BotState.pkg
        BotState.pkg = pkg
        if (pkg.isNotEmpty() && !pkg.startsWith("com.epicgames.")) {
            if (lastWait != pkg) {
                lastWait = pkg
                BotState.log("Esperando a Fortnite (ahora: " + pkg + ")")
            }
            return
        }
        lastWait = ""
        busy = true
        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            bg,
            object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    handleShot(result)
                }

                override fun onFailure(errorCode: Int) {
                    if (errorCode != lastErr) {
                        lastErr = errorCode
                        BotState.log("No se pudo capturar la pantalla (codigo " + errorCode + ")")
                    }
                    busy = false
                }
            }
        )
    }

    private fun handleShot(r: AccessibilityService.ScreenshotResult) {
        var soft: Bitmap? = null
        try {
            val hb = r.hardwareBuffer
            val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
            soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
            hw?.recycle()
            hb.close()
        } catch (e: Exception) {
            BotState.log("Error al leer la captura: " + e.message)
        }
        val bmp = soft
        if (bmp == null) {
            busy = false
            return
        }
        BotState.scans = BotState.scans + 1
        val p = Cfg.prefs(this)
        val thr = p.getInt("thr", 75) / 100f
        val mode = p.getString("afterMatch", "again") ?: "again"
        val tapped = try {
            matchTemplates(bmp, mode, thr)
        } catch (e: Exception) {
            BotState.log("Error de imagen: " + e.message)
            false
        }
        if (tapped) {
            bmp.recycle()
            busy = false
            return
        }
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { text -> onText(text) }
            .addOnCompleteListener {
                bmp.recycle()
                busy = false
            }
    }

    private fun matchTemplates(bmp: Bitmap, mode: String, thr: Float): Boolean {
        val w4 = bmp.width / 4
        val h4 = bmp.height / 4
        val small = Bitmap.createScaledBitmap(bmp, w4, h4, true)
        val px = IntArray(w4 * h4)
        small.getPixels(px, 0, w4, 0, 0, w4, h4)
        if (small !== bmp) small.recycle()
        val g = IntArray(w4 * h4)
        for (i in px.indices) g[i] = Matcher.gray(px[i])
        val scale = bmp.height / 1080f
        val after = if (mode == "lobby") "lobby" else "again"
        val p = Cfg.prefs(this)
        val info = StringBuilder()
        for (key in listOf(after, "play")) {
            val prep = Matcher.prep(this, key, scale)
            val hit = Matcher.find(g, w4, h4, prep)
            val sc = String.format(Locale.US, "%.2f", hit.score)
            info.append(key).append(' ').append(sc).append("  ")
            if (hit.score >= thr) {
                val name: String
                val delay: Int
                if (key == "again") {
                    name = "Jugar de nuevo"
                    delay = p.getInt("dAgain", 30)
                } else if (key == "lobby") {
                    name = "Volver a la sala"
                    delay = p.getInt("dLobby", 10)
                } else {
                    name = "Jugar / Listo"
                    delay = p.getInt("dReady", 30)
                }
                tap(hit.cx.toFloat(), hit.cy.toFloat())
                BotState.log("Pulsado: " + name + " (" + sc + ")")
                BotState.info = info.toString()
                pausedUntil = System.currentTimeMillis() + delay * 1000L
                return true
            }
        }
        BotState.info = info.toString()
        return false
    }

    private fun onText(text: Text) {
        val p: SharedPreferences = Cfg.prefs(this)
        val groups = listOf(
            Triple("Listo", Cfg.list(p, "kwReady"), p.getInt("dReady", 30)),
            Triple("Jugar de nuevo", Cfg.list(p, "kwAgain"), p.getInt("dAgain", 30)),
            Triple("Volver a la sala", Cfg.list(p, "kwLobby"), p.getInt("dLobby", 10))
        )
        for ((name, kws, delay) in groups) {
            for (block in text.textBlocks) {
                for (line in block.lines) {
                    val box = line.boundingBox ?: continue
                    val t = clean(line.text)
                    if (kws.contains(t)) {
                        tap(box.centerX().toFloat(), box.centerY().toFloat())
                        BotState.log("Pulsado por texto: " + name)
                        pausedUntil = System.currentTimeMillis() + delay * 1000L
                        return
                    }
                }
            }
        }
    }

    private fun tap(x: Float, y: Float) {
        val path = Path()
        path.moveTo(x, y)
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}
