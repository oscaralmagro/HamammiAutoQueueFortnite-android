package com.oscaralmagro.autoqueue

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors

class QueueService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    @Volatile
    private var busy = false
    private var pausedUntil = 0L

    private val tick = object : Runnable {
        override fun run() {
            try {
                scan()
            } catch (e: Exception) {
                busy = false
            }
            val sec = Cfg.prefs(this@QueueService).getInt("interval", 3)
            handler.postDelayed(this, sec * 1000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        BotState.serviceOn = true
        BotState.log("Servicio de accesibilidad activo.")
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        BotState.serviceOn = false
        BotState.running = false
        handler.removeCallbacks(tick)
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            BotState.pkg = e.packageName?.toString() ?: ""
        }
    }

    private fun scan() {
        if (!BotState.running || busy) return
        if (!BotState.pkg.startsWith("com.epicgames.")) return
        if (System.currentTimeMillis() < pausedUntil) return
        busy = true
        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            bg,
            object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    handleShot(result)
                }

                override fun onFailure(errorCode: Int) {
                    busy = false
                }
            }
        )
    }

    private fun handleShot(r: AccessibilityService.ScreenshotResult) {
        var soft: Bitmap? = null
        try {
            val hb = r.hardwareBuffer
            val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
            soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
            hw?.recycle()
            hb.close()
        } catch (e: Exception) {
        }
        val bmp = soft
        if (bmp == null) {
            busy = false
            return
        }
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { text -> onText(text) }
            .addOnCompleteListener {
                bmp.recycle()
                busy = false
            }
    }

    private fun onText(text: Text) {
        val p = Cfg.prefs(this)
        val groups = listOf(
            Triple("Listo", Cfg.list(p, "kwReady"), p.getInt("dReady", 30)),
            Triple("Jugar de nuevo", Cfg.list(p, "kwAgain"), p.getInt("dAgain", 30)),
            Triple("Volver a la sala", Cfg.list(p, "kwLobby"), p.getInt("dLobby", 10))
        )
        for ((name, kws, delay) in groups) {
            for (block in text.textBlocks) {
                for (line in block.lines) {
                    val box = line.boundingBox ?: continue
                    val t = clean(line.text)
                    if (kws.contains(t)) {
                        tap(box.centerX().toFloat(), box.centerY().toFloat())
                        BotState.log("Pulsado: " + name)
                        pausedUntil = System.currentTimeMillis() + delay * 1000L
                        return
                    }
                }
            }
        }
    }

    private fun tap(x: Float, y: Float) {
        val path = Path()
        path.moveTo(x, y)
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}
